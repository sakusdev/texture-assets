TAfC — Concrete Wall 001
Maps: Base Color, Normal, Roughness, Height, AO
Resolution: 4K
Seamless / tileable.
