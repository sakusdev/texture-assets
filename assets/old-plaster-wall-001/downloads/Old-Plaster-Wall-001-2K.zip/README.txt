TAfC — Old Plaster Wall
Maps: Base Color, Normal, Roughness, Height, AO
Resolution: 2K
Seamless / tileable.
