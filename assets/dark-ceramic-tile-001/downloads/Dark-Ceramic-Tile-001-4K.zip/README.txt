TAfC — Dark Ceramic Tile
Maps: Base Color, Normal, Roughness, Height, AO
Resolution: 4K
Seamless / tileable.
