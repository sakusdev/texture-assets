TAfC — Dark Ceramic Tile
Maps: Base Color, Normal, Roughness, Height, AO
Resolution: 2K
Seamless / tileable.
