TAfC — Wet Concrete Floor
Maps: Base Color, Normal, Roughness, Height, AO
Resolution: 2K
Seamless / tileable.
