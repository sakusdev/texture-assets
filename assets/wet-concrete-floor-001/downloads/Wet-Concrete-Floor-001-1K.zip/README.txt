TAfC — Wet Concrete Floor
Maps: Base Color, Normal, Roughness, Height, AO
Resolution: 1K
Seamless / tileable.
