TAfC — Rusty Metal Panel
Maps: Base Color, Normal, Roughness, Height, AO, Metallic
Resolution: 2K
Seamless / tileable.
