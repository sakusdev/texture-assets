TAfC — Rusty Metal Panel
Maps: Base Color, Normal, Roughness, Height, AO, Metallic
Resolution: 1K
Seamless / tileable.
