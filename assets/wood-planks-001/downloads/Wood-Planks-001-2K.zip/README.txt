TAfC — Wood Planks 001
Maps: Base Color, Normal, Roughness, Height, AO
Resolution: 2K
Seamless / tileable.
