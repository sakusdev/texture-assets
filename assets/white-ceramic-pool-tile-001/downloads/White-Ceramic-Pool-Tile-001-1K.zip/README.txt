TAfC — White Ceramic Pool Tile 001
Maps: Base Color, Normal, Roughness, Height, AO
Resolution: 1K
Seamless / tileable.
